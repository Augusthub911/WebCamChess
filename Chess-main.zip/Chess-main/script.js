let chess = new Chess();
let chessboard = new Chessboard('chessboard', 'standard', 'white', 'black');
let turnCounter = 0;
let history = [];

document.addEventListener("keydown", function(event) {
    let move = chess.move(event.key);
    if (move) {
        turnCounter++;
        history.push({ move: move, turn: turnCounter });
        updateHistory();
        if (checkForCheckmate()) {
            gameOver();
        }
    }
});

function updateHistory() {
    let historyHtml = "";
    for (let i = 0; i < history.length; i++) {
        historyHtml += `<p>Turn ${history[i].turn}: ${history[i].move}</p>`;
    }
    document.getElementById("history").innerHTML = historyHtml;
}

function checkForCheckmate() {
    let checkmate = chess.isCheckmate();
    if (checkmate) {
        alert(`Checkmate! ${checkmate.color} wins.`);
        return true;
    }
    return false;
}

function gameOver() {
    let statistics = getStatistics();
    alert(`Game over! ${statistics.white} ${statistics.black} ${statistics.result}`);
}

function getStatistics() {
    let statistics = {};
    statistics.white = `White: ${turnCounter} moves`;
    statistics.black = `Black: ${turnCounter} moves`;
    statistics.result = chess.result();
    return statistics;
}
